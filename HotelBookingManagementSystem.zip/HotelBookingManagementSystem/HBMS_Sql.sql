select * from hotel;

create sequence Admin_id_Sequence start with 1 increment by 1;
create sequence Employee_id_Sequence start with 1 increment by 1;	
create sequence Customer_id_Sequence start with 1 increment by 1;
create sequence Hotel_id_Sequence start with 1 increment by 1;
create sequence Room_id_Sequence start with 1 increment by 1;

INSERT INTO USERS VALUES ('A'||TO_CHAR(Admin_id_Sequence.NEXTVAL,'FM00'),'A123','Admin','Admin','9875421037','922310','Kolkata','admin@gmail.com');
INSERT INTO USERS VALUES ('C'||TO_CHAR(Customer_id_Sequence.NEXTVAL,'FM00'),'Kg123','Customer','Krishna','9876421037','922330','Kolkata','kg@gmail.com');

delete from users where user_id in ('1','5','6','7');